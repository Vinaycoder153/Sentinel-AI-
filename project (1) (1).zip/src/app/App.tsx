import { useState } from 'react';
import { Shield, LayoutDashboard, AlertTriangle, Brain, Activity, Wrench, Layers, FileText, Menu, X } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { BiasDetectionEngine } from './components/BiasDetectionEngine';
import { ExplainabilityEngine } from './components/ExplainabilityEngine';
import { DecisionFirewall } from './components/DecisionFirewall';
import { AutoHealingEngine } from './components/AutoHealingEngine';
import { DigitalTwinSimulator } from './components/DigitalTwinSimulator';
import { AuditLedger } from './components/AuditLedger';

type NavItem = {
  id: string;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
};

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
  { id: 'bias-detection', label: 'Bias Detection', icon: AlertTriangle },
  { id: 'explainability', label: 'Explainability', icon: Brain },
  { id: 'firewall', label: 'Decision Firewall', icon: Activity },
  { id: 'auto-healing', label: 'Auto-Healing', icon: Wrench },
  { id: 'digital-twin', label: 'Digital Twin', icon: Layers },
  { id: 'audit', label: 'Audit Ledger', icon: FileText },
];

export default function App() {
  const [activeView, setActiveView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'bias-detection':
        return <BiasDetectionEngine />;
      case 'explainability':
        return <ExplainabilityEngine />;
      case 'firewall':
        return <DecisionFirewall />;
      case 'auto-healing':
        return <AutoHealingEngine />;
      case 'digital-twin':
        return <DigitalTwinSimulator />;
      case 'audit':
        return <AuditLedger />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="flex h-screen overflow-hidden">
        <aside className={`bg-gray-900/50 backdrop-blur-sm border-r border-gray-700 transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}>
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-700">
              {sidebarOpen && (
                <div className="flex items-center gap-3">
                  <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-2 rounded-lg">
                    <Shield className="text-white" size={24} />
                  </div>
                  <div>
                    <h1 className="text-white font-bold text-lg">SENTINEL AI-X</h1>
                    <p className="text-gray-400 text-xs">Governance Engine</p>
                  </div>
                </div>
              )}
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>

            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveView(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      isActive
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                    }`}
                  >
                    <Icon size={20} className={isActive ? 'text-blue-400' : ''} />
                    {sidebarOpen && (
                      <span className="font-medium">{item.label}</span>
                    )}
                  </button>
                );
              })}
            </nav>

            <div className="p-4 border-t border-gray-700">
              <div className={`bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-lg p-3 ${
                !sidebarOpen && 'flex justify-center'
              }`}>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  {sidebarOpen && (
                    <span className="text-green-400 text-sm font-semibold">System Active</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto">
          <div className="bg-gray-900/30 border-b border-gray-700 backdrop-blur-sm sticky top-0 z-10">
            <div className="flex items-center justify-between p-6">
              <div className="flex items-center gap-4">
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-2">
                  <span className="text-gray-400 text-sm">Environment:</span>
                  <span className="text-white font-semibold ml-2">Production</span>
                </div>
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-2">
                  <span className="text-gray-400 text-sm">Last Updated:</span>
                  <span className="text-white font-semibold ml-2">2 seconds ago</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg px-4 py-2">
                  <span className="text-blue-400 font-semibold">Google Cloud Connected</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-8">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}