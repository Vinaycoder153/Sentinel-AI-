import { Brain, Info } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const shapValues = [
  { feature: 'Credit Score', impact: 0.42, direction: 'positive' },
  { feature: 'Income Level', impact: 0.28, direction: 'positive' },
  { feature: 'Age', impact: -0.31, direction: 'negative' },
  { feature: 'Gender', impact: -0.38, direction: 'negative' },
  { feature: 'Employment Status', impact: 0.19, direction: 'positive' },
  { feature: 'Location', impact: -0.15, direction: 'negative' },
  { feature: 'Education', impact: 0.22, direction: 'positive' },
  { feature: 'Debt Ratio', impact: -0.26, direction: 'negative' },
];

const selectedPrediction = {
  id: 'PRED-2024-4892',
  input: {
    creditScore: 720,
    income: 85000,
    age: 34,
    gender: 'Female',
    employment: 'Full-time',
    location: 'Urban',
  },
  prediction: 'Denied',
  confidence: 0.76,
  biasScore: 0.42,
};

export function ExplainabilityEngine() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Explainability Engine</h2>
          <p className="text-gray-400 mt-1">SHAP-powered interpretability for every decision</p>
        </div>
        <div className="flex items-center gap-2 bg-blue-500/20 border border-blue-500/30 rounded-lg px-4 py-2">
          <Brain className="text-blue-400" size={20} />
          <span className="text-blue-400 font-semibold">AI Insights Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Feature Impact Analysis (SHAP Values)</h3>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={shapValues} layout="vertical" margin={{ left: 100 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis type="number" tick={{ fill: '#9CA3AF' }} label={{ value: 'Impact on Prediction', position: 'insideBottom', fill: '#9CA3AF', offset: -5 }} />
              <YAxis dataKey="feature" type="category" tick={{ fill: '#9CA3AF' }} width={120} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                labelStyle={{ color: '#F3F4F6' }}
              />
              <Bar dataKey="impact" radius={[0, 4, 4, 0]}>
                {shapValues.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.direction === 'positive' ? '#10B981' : '#EF4444'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 flex gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-sm text-gray-400">Positive Impact</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span className="text-sm text-gray-400">Negative Impact</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Selected Prediction</h3>
          <div className="space-y-4">
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
              <div className="text-xs text-gray-500 mb-1">Prediction ID</div>
              <div className="text-white font-mono text-sm">{selectedPrediction.id}</div>
            </div>

            <div className="space-y-2">
              <div className="text-sm text-gray-400">Input Features:</div>
              {Object.entries(selectedPrediction.input).map(([key, value]) => (
                <div key={key} className="flex justify-between text-sm">
                  <span className="text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                  <span className="text-white font-medium">{value}</span>
                </div>
              ))}
            </div>

            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-1">Prediction</div>
              <div className="text-2xl font-bold text-red-400">{selectedPrediction.prediction}</div>
              <div className="text-sm text-gray-400 mt-2">Confidence: {(selectedPrediction.confidence * 100).toFixed(1)}%</div>
            </div>

            <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-1">Bias Score</div>
              <div className="text-2xl font-bold text-yellow-400">{(selectedPrediction.biasScore * 100).toFixed(0)}/100</div>
              <div className="text-sm text-yellow-400 mt-1">⚠️ Requires Review</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/30 rounded-xl p-6">
        <div className="flex items-start gap-3">
          <Info className="text-blue-400 mt-1" size={20} />
          <div className="flex-1">
            <h4 className="text-white font-semibold mb-2">Root Cause Analysis</h4>
            <p className="text-gray-300 text-sm mb-3">
              The model's decision to deny was heavily influenced by <span className="text-red-400 font-semibold">Gender (-38%)</span> and <span className="text-red-400 font-semibold">Age (-31%)</span>, despite strong positive indicators from Credit Score (+42%) and Income Level (+28%). This pattern suggests potential discriminatory bias in the decision boundary.
            </p>
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Recommendation</div>
              <div className="text-sm text-gray-300">
                Enable <span className="text-blue-400 font-semibold">Auto-Healing</span> to re-weight protected attributes and improve fairness without sacrificing accuracy.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
