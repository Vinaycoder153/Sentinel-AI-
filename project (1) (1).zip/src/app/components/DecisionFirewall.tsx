import { Shield, Activity, Zap, Clock } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useState, useEffect } from 'react';

const realtimeData = [
  { time: '14:00', predictions: 45, blocked: 8, corrected: 12 },
  { time: '14:05', predictions: 52, blocked: 11, corrected: 15 },
  { time: '14:10', predictions: 48, blocked: 9, corrected: 13 },
  { time: '14:15', predictions: 61, blocked: 14, corrected: 18 },
  { time: '14:20', predictions: 55, blocked: 10, corrected: 16 },
  { time: '14:25', predictions: 58, blocked: 12, corrected: 17 },
  { time: '14:30', predictions: 63, blocked: 15, corrected: 19 },
];

const recentInterceptions = [
  { id: 'INT-8921', model: 'Credit-ML-v3', biasScore: 0.78, action: 'corrected', timestamp: '2s ago' },
  { id: 'INT-8920', model: 'Hiring-DL-v2', biasScore: 0.92, action: 'blocked', timestamp: '5s ago' },
  { id: 'INT-8919', model: 'Credit-ML-v3', biasScore: 0.81, action: 'corrected', timestamp: '8s ago' },
  { id: 'INT-8918', model: 'Loan-RF-v4', biasScore: 0.69, action: 'corrected', timestamp: '12s ago' },
  { id: 'INT-8917', model: 'Hiring-DL-v2', biasScore: 0.95, action: 'blocked', timestamp: '15s ago' },
];

export function DecisionFirewall() {
  const [metrics, setMetrics] = useState({
    totalPredictions: 1847,
    intercepted: 234,
    corrected: 312,
    blocked: 89,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        totalPredictions: prev.totalPredictions + Math.floor(Math.random() * 3),
        intercepted: prev.intercepted + (Math.random() > 0.7 ? 1 : 0),
        corrected: prev.corrected + (Math.random() > 0.8 ? 1 : 0),
        blocked: prev.blocked + (Math.random() > 0.9 ? 1 : 0),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Decision Firewall</h2>
          <p className="text-gray-400 mt-1">Real-time interception and correction of biased predictions</p>
        </div>
        <div className="flex items-center gap-2 bg-green-500/20 border border-green-500/30 rounded-lg px-4 py-2">
          <Activity className="text-green-400 animate-pulse" size={20} />
          <span className="text-green-400 font-semibold">Live Monitoring</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Shield className="text-blue-400" size={24} />
            <Activity className="text-blue-400" size={16} />
          </div>
          <div className="text-3xl font-bold text-white mb-1">{metrics.totalPredictions.toLocaleString()}</div>
          <div className="text-sm text-blue-400">Total Predictions</div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Zap className="text-yellow-400" size={24} />
            <Clock className="text-yellow-400" size={16} />
          </div>
          <div className="text-3xl font-bold text-white mb-1">{metrics.intercepted}</div>
          <div className="text-sm text-yellow-400">Intercepted</div>
          <div className="text-xs text-yellow-400/70 mt-1">{((metrics.intercepted / metrics.totalPredictions) * 100).toFixed(1)}% rate</div>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Shield className="text-green-400" size={24} />
            <Zap className="text-green-400" size={16} />
          </div>
          <div className="text-3xl font-bold text-white mb-1">{metrics.corrected}</div>
          <div className="text-sm text-green-400">Auto-Corrected</div>
          <div className="text-xs text-green-400/70 mt-1">Fairness improved</div>
        </div>

        <div className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Shield className="text-red-400" size={24} />
            <Zap className="text-red-400" size={16} />
          </div>
          <div className="text-3xl font-bold text-white mb-1">{metrics.blocked}</div>
          <div className="text-sm text-red-400">Blocked</div>
          <div className="text-xs text-red-400/70 mt-1">High-risk decisions</div>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Real-Time Activity</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={realtimeData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="time" tick={{ fill: '#9CA3AF' }} />
            <YAxis tick={{ fill: '#9CA3AF' }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
              labelStyle={{ color: '#F3F4F6' }}
            />
            <Legend wrapperStyle={{ color: '#9CA3AF' }} />
            <Line type="monotone" dataKey="predictions" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4 }} name="Total Predictions" />
            <Line type="monotone" dataKey="blocked" stroke="#EF4444" strokeWidth={2} dot={{ r: 4 }} name="Blocked" />
            <Line type="monotone" dataKey="corrected" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} name="Corrected" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Recent Interceptions</h3>
        <div className="space-y-3">
          {recentInterceptions.map((item) => (
            <div key={item.id} className="bg-gray-900/50 border border-gray-700 rounded-lg p-4 flex items-center justify-between hover:border-gray-600 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`w-2 h-2 rounded-full ${item.action === 'blocked' ? 'bg-red-500 animate-pulse' : 'bg-green-500 animate-pulse'}`} />
                <div>
                  <div className="text-white font-mono text-sm">{item.id}</div>
                  <div className="text-gray-500 text-xs">{item.model}</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm text-gray-400">Bias Score</div>
                  <div className={`font-semibold ${item.biasScore > 0.8 ? 'text-red-400' : 'text-yellow-400'}`}>
                    {(item.biasScore * 100).toFixed(0)}%
                  </div>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  item.action === 'blocked'
                    ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                    : 'bg-green-500/20 text-green-400 border border-green-500/30'
                }`}>
                  {item.action.toUpperCase()}
                </div>
                <div className="text-xs text-gray-500 w-16 text-right">{item.timestamp}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
