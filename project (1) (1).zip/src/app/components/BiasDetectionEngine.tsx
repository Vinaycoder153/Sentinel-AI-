import { AlertTriangle, CheckCircle, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';

const fairnessMetrics = [
  { metric: 'Demographic Parity', score: 0.67, threshold: 0.8, status: 'warning' },
  { metric: 'Equal Opportunity', score: 0.73, threshold: 0.8, status: 'warning' },
  { metric: 'Equalized Odds', score: 0.58, threshold: 0.8, status: 'critical' },
  { metric: 'Predictive Parity', score: 0.85, threshold: 0.8, status: 'good' },
];

const attributeBias = [
  { attribute: 'Gender', bias: 0.42, impact: 'high' },
  { attribute: 'Age', bias: 0.28, impact: 'medium' },
  { attribute: 'Race', bias: 0.51, impact: 'critical' },
  { attribute: 'Location', bias: 0.19, impact: 'low' },
];

const radarData = [
  { metric: 'Fairness', value: 65, fullMark: 100 },
  { metric: 'Accuracy', value: 92, fullMark: 100 },
  { metric: 'Robustness', value: 78, fullMark: 100 },
  { metric: 'Transparency', value: 71, fullMark: 100 },
  { metric: 'Accountability', value: 83, fullMark: 100 },
];

export function BiasDetectionEngine() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Bias Detection Engine</h2>
          <p className="text-gray-400 mt-1">Real-time fairness analysis across protected attributes</p>
        </div>
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg px-4 py-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="text-red-400" size={20} />
            <span className="text-red-400 font-semibold">Bias Detected</span>
          </div>
          <div className="text-red-300 text-sm mt-1">Overall Score: 68/100</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Fairness Metrics</h3>
          <div className="space-y-4">
            {fairnessMetrics.map((item) => (
              <div key={item.metric}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-300">{item.metric}</span>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-semibold ${
                      item.status === 'good' ? 'text-green-400' :
                      item.status === 'warning' ? 'text-yellow-400' :
                      'text-red-400'
                    }`}>
                      {(item.score * 100).toFixed(0)}%
                    </span>
                    {item.status === 'good' ? (
                      <CheckCircle size={16} className="text-green-400" />
                    ) : (
                      <AlertTriangle size={16} className={item.status === 'critical' ? 'text-red-400' : 'text-yellow-400'} />
                    )}
                  </div>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full transition-all ${
                      item.status === 'good' ? 'bg-green-500' :
                      item.status === 'warning' ? 'bg-yellow-500' :
                      'bg-red-500'
                    }`}
                    style={{ width: `${item.score * 100}%` }}
                  />
                </div>
                <div className="text-xs text-gray-500 mt-1">Threshold: {(item.threshold * 100).toFixed(0)}%</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Model Performance Radar</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#374151" />
              <PolarAngleAxis dataKey="metric" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
              <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#9CA3AF' }} />
              <Radar name="Current Model" dataKey="value" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                labelStyle={{ color: '#F3F4F6' }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Attribute Bias Analysis</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={attributeBias}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="attribute" tick={{ fill: '#9CA3AF' }} />
            <YAxis tick={{ fill: '#9CA3AF' }} label={{ value: 'Bias Score', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
              labelStyle={{ color: '#F3F4F6' }}
            />
            <Bar dataKey="bias" fill="#EF4444" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="grid grid-cols-4 gap-4 mt-4">
          {attributeBias.map((attr) => (
            <div key={attr.attribute} className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-gray-400 text-sm">{attr.attribute}</div>
              <div className="text-2xl font-bold text-white mt-1">{(attr.bias * 100).toFixed(0)}%</div>
              <div className={`text-xs mt-1 ${
                attr.impact === 'critical' ? 'text-red-400' :
                attr.impact === 'high' ? 'text-orange-400' :
                attr.impact === 'medium' ? 'text-yellow-400' :
                'text-green-400'
              }`}>
                {attr.impact.toUpperCase()} IMPACT
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
