import { Layers, PlayCircle, RotateCcw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useState } from 'react';

const baselineMetrics = [
  { metric: 'Demographic Parity', baseline: 67, scenario1: 82, scenario2: 78 },
  { metric: 'Equal Opportunity', baseline: 73, scenario1: 85, scenario2: 80 },
  { metric: 'Accuracy', baseline: 92, scenario1: 88, scenario2: 90 },
  { metric: 'Precision', baseline: 89, scenario1: 86, scenario2: 88 },
];

const scenarios = [
  {
    id: 1,
    name: 'Remove Gender Attribute',
    description: 'Simulate model behavior without gender as input feature',
    parameters: {
      removedAttributes: ['gender'],
      retrainRequired: true,
      estimatedTime: '15 min',
    },
    results: {
      fairnessGain: '+22%',
      accuracyLoss: '-4%',
      status: 'completed',
    },
  },
  {
    id: 2,
    name: 'Balanced Dataset',
    description: 'Equal representation across demographic groups',
    parameters: {
      samplingStrategy: 'Stratified',
      targetDistribution: 'Uniform',
      estimatedTime: '8 min',
    },
    results: {
      fairnessGain: '+16%',
      accuracyLoss: '-2%',
      status: 'completed',
    },
  },
  {
    id: 3,
    name: 'Threshold Calibration',
    description: 'Group-specific decision thresholds',
    parameters: {
      calibrationMethod: 'Equal Opportunity',
      groupCount: 4,
      estimatedTime: '5 min',
    },
    results: null,
    status: 'pending',
  },
];

export function DigitalTwinSimulator() {
  const [activeScenario, setActiveScenario] = useState(1);
  const [isSimulating, setIsSimulating] = useState(false);

  const runSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => setIsSimulating(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Digital Twin Simulator</h2>
          <p className="text-gray-400 mt-1">What-if analysis for bias mitigation strategies</p>
        </div>
        <div className="flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 rounded-lg px-4 py-2">
          <Layers className="text-purple-400" size={20} />
          <span className="text-purple-400 font-semibold">3 Scenarios Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Scenario Comparison</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={baselineMetrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="metric" tick={{ fill: '#9CA3AF', fontSize: 11 }} angle={-15} textAnchor="end" height={80} />
              <YAxis tick={{ fill: '#9CA3AF' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                labelStyle={{ color: '#F3F4F6' }}
              />
              <Legend wrapperStyle={{ color: '#9CA3AF' }} />
              <Bar dataKey="baseline" fill="#6B7280" name="Current Model" radius={[4, 4, 0, 0]} />
              <Bar dataKey="scenario1" fill="#8B5CF6" name="Remove Gender" radius={[4, 4, 0, 0]} />
              <Bar dataKey="scenario2" fill="#10B981" name="Balanced Dataset" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>

          <div className="mt-6 bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">Key Insights</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-purple-400">•</span>
                <span>Removing gender attribute yields <span className="text-purple-400 font-semibold">+22% fairness</span> with only <span className="text-red-400">-4% accuracy</span> trade-off</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-400">•</span>
                <span>Balanced dataset strategy achieves <span className="text-green-400 font-semibold">+16% fairness</span> with minimal <span className="text-red-400">-2% accuracy</span> loss</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400">•</span>
                <span>Recommended approach: <span className="text-blue-400 font-semibold">Hybrid strategy</span> combining both techniques</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Simulation Control</h3>
          <div className="space-y-4">
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-2">Active Scenario</div>
              <div className="text-white font-semibold">{scenarios.find(s => s.id === activeScenario)?.name}</div>
            </div>

            <div className="space-y-2">
              <div className="text-sm text-gray-400 mb-2">Parameters</div>
              {Object.entries(scenarios.find(s => s.id === activeScenario)?.parameters || {}).map(([key, value]) => (
                <div key={key} className="flex justify-between text-sm">
                  <span className="text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                  <span className="text-white">{value}</span>
                </div>
              ))}
            </div>

            {scenarios.find(s => s.id === activeScenario)?.results && (
              <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-2">Results</div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-xs text-gray-400">Fairness</div>
                    <div className="text-lg font-bold text-green-400">
                      {scenarios.find(s => s.id === activeScenario)?.results?.fairnessGain}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Accuracy</div>
                    <div className="text-lg font-bold text-red-400">
                      {scenarios.find(s => s.id === activeScenario)?.results?.accuracyLoss}
                    </div>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-semibold transition-all ${
                isSimulating
                  ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  : 'bg-purple-500 hover:bg-purple-600 text-white'
              }`}
            >
              {isSimulating ? (
                <>
                  <RotateCcw className="animate-spin" size={20} />
                  Simulating...
                </>
              ) : (
                <>
                  <PlayCircle size={20} />
                  Run Simulation
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Scenario Library</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {scenarios.map((scenario) => (
            <div
              key={scenario.id}
              onClick={() => setActiveScenario(scenario.id)}
              className={`border rounded-xl p-5 cursor-pointer transition-all ${
                activeScenario === scenario.id
                  ? 'bg-purple-500/10 border-purple-500/30 hover:border-purple-500/50'
                  : 'bg-gray-900/50 border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="text-white font-semibold flex-1">{scenario.name}</h4>
                <div className={`w-3 h-3 rounded-full ${
                  scenario.results ? 'bg-green-500' : 'bg-gray-600'
                }`} />
              </div>
              <p className="text-gray-400 text-sm mb-3">{scenario.description}</p>
              {scenario.results && (
                <div className="flex gap-2 text-xs">
                  <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded">{scenario.results.fairnessGain}</span>
                  <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded">{scenario.results.accuracyLoss}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
