import { Shield, TrendingUp, Activity, AlertTriangle, CheckCircle, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const overviewData = [
  { date: 'Apr 21', fairness: 62, predictions: 1240 },
  { date: 'Apr 22', fairness: 65, predictions: 1380 },
  { date: 'Apr 23', fairness: 68, predictions: 1520 },
  { date: 'Apr 24', fairness: 72, predictions: 1690 },
  { date: 'Apr 25', fairness: 76, predictions: 1820 },
  { date: 'Apr 26', fairness: 80, predictions: 1950 },
  { date: 'Apr 27', fairness: 82, predictions: 2140 },
  { date: 'Apr 28', fairness: 85, predictions: 2280 },
];

const modelStats = [
  { model: 'Credit-ML-v3', status: 'active', fairness: 85, predictions: 4892, corrections: 412 },
  { model: 'Hiring-DL-v2', status: 'active', fairness: 78, predictions: 2156, corrections: 289 },
  { model: 'Loan-RF-v4', status: 'active', fairness: 91, predictions: 3421, corrections: 156 },
  { model: 'Insurance-NN-v1', status: 'monitoring', fairness: 68, predictions: 1847, corrections: 534 },
];

const recentAlerts = [
  { id: 1, severity: 'critical', message: 'Hiring-DL-v2 showing demographic parity violation', time: '2m ago' },
  { id: 2, severity: 'warning', message: 'Insurance-NN-v1 bias score increased to 68%', time: '15m ago' },
  { id: 3, severity: 'info', message: 'Auto-healing completed for Credit-ML-v3', time: '32m ago' },
];

export function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white">Governance Overview</h2>
        <p className="text-gray-400 mt-1">Real-time AI fairness monitoring across all deployed models</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <Shield className="text-blue-400" size={28} />
            <div className="bg-blue-500/20 rounded-full p-2">
              <TrendingUp className="text-blue-400" size={16} />
            </div>
          </div>
          <div className="text-3xl font-bold text-white mb-1">85%</div>
          <div className="text-sm text-blue-400">Overall Fairness</div>
          <div className="text-xs text-blue-400/70 mt-1">+23% from baseline</div>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <Activity className="text-green-400" size={28} />
            <div className="bg-green-500/20 rounded-full p-2">
              <CheckCircle className="text-green-400" size={16} />
            </div>
          </div>
          <div className="text-3xl font-bold text-white mb-1">10,516</div>
          <div className="text-sm text-green-400">Total Predictions</div>
          <div className="text-xs text-green-400/70 mt-1">Last 7 days</div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <Zap className="text-yellow-400" size={28} />
            <div className="bg-yellow-500/20 rounded-full p-2">
              <Activity className="text-yellow-400" size={16} />
            </div>
          </div>
          <div className="text-3xl font-bold text-white mb-1">1,391</div>
          <div className="text-sm text-yellow-400">Auto-Corrected</div>
          <div className="text-xs text-yellow-400/70 mt-1">13.2% intervention rate</div>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <Shield className="text-purple-400" size={28} />
            <div className="bg-purple-500/20 rounded-full p-2">
              <CheckCircle className="text-purple-400" size={16} />
            </div>
          </div>
          <div className="text-3xl font-bold text-white mb-1">4</div>
          <div className="text-sm text-purple-400">Active Models</div>
          <div className="text-xs text-purple-400/70 mt-1">Under governance</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Fairness Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={overviewData}>
              <defs>
                <linearGradient id="fairnessGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" tick={{ fill: '#9CA3AF' }} />
              <YAxis tick={{ fill: '#9CA3AF' }} label={{ value: 'Fairness Score (%)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                labelStyle={{ color: '#F3F4F6' }}
              />
              <Area type="monotone" dataKey="fairness" stroke="#10B981" strokeWidth={3} fill="url(#fairnessGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">System Alerts</h3>
          <div className="space-y-3">
            {recentAlerts.map((alert) => (
              <div key={alert.id} className={`border rounded-lg p-3 ${
                alert.severity === 'critical' ? 'bg-red-500/10 border-red-500/30' :
                alert.severity === 'warning' ? 'bg-yellow-500/10 border-yellow-500/30' :
                'bg-blue-500/10 border-blue-500/30'
              }`}>
                <div className="flex items-start gap-2">
                  {alert.severity === 'critical' ? (
                    <AlertTriangle className="text-red-400 mt-0.5" size={16} />
                  ) : alert.severity === 'warning' ? (
                    <AlertTriangle className="text-yellow-400 mt-0.5" size={16} />
                  ) : (
                    <CheckCircle className="text-blue-400 mt-0.5" size={16} />
                  )}
                  <div className="flex-1">
                    <p className={`text-sm ${
                      alert.severity === 'critical' ? 'text-red-300' :
                      alert.severity === 'warning' ? 'text-yellow-300' :
                      'text-blue-300'
                    }`}>
                      {alert.message}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Model Performance</h3>
        <div className="space-y-4">
          {modelStats.map((model) => (
            <div key={model.model} className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    model.status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'
                  }`} />
                  <span className="text-white font-semibold">{model.model}</span>
                  <span className={`text-xs px-2 py-1 rounded ${
                    model.status === 'active'
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {model.status.toUpperCase()}
                  </span>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-gray-400">Predictions: </span>
                    <span className="text-white font-semibold">{model.predictions.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Corrections: </span>
                    <span className="text-yellow-400 font-semibold">{model.corrections}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-400">Fairness Score</span>
                    <span className={`text-sm font-semibold ${
                      model.fairness >= 85 ? 'text-green-400' :
                      model.fairness >= 75 ? 'text-yellow-400' :
                      'text-red-400'
                    }`}>
                      {model.fairness}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        model.fairness >= 85 ? 'bg-green-500' :
                        model.fairness >= 75 ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`}
                      style={{ width: `${model.fairness}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
