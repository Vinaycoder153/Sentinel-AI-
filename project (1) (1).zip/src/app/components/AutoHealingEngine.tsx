import { Wrench, TrendingUp, Play, Pause } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useState } from 'react';

const performanceData = [
  { iteration: 0, fairness: 65, accuracy: 92 },
  { iteration: 1, fairness: 68, accuracy: 91 },
  { iteration: 2, fairness: 72, accuracy: 90 },
  { iteration: 3, fairness: 76, accuracy: 89 },
  { iteration: 4, fairness: 79, accuracy: 88 },
  { iteration: 5, fairness: 82, accuracy: 88 },
  { iteration: 6, fairness: 85, accuracy: 87 },
];

const techniques = [
  {
    id: 1,
    name: 'Re-weighting',
    description: 'Adjust sample weights to balance representation across protected groups',
    enabled: true,
    impact: '+12% fairness',
    status: 'active',
  },
  {
    id: 2,
    name: 'Threshold Optimization',
    description: 'Calibrate decision thresholds per demographic group',
    enabled: true,
    impact: '+8% fairness',
    status: 'active',
  },
  {
    id: 3,
    name: 'Adversarial Debiasing',
    description: 'Train adversarial network to remove protected attribute signals',
    enabled: false,
    impact: '+15% fairness',
    status: 'idle',
  },
  {
    id: 4,
    name: 'Fairness Constraints',
    description: 'Add regularization terms to enforce demographic parity',
    enabled: false,
    impact: '+10% fairness',
    status: 'idle',
  },
];

export function AutoHealingEngine() {
  const [isHealing, setIsHealing] = useState(true);
  const [activeTechniques, setActiveTechniques] = useState([1, 2]);

  const toggleTechnique = (id: number) => {
    setActiveTechniques(prev =>
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Auto-Healing Engine</h2>
          <p className="text-gray-400 mt-1">Automated bias correction and fairness optimization</p>
        </div>
        <button
          onClick={() => setIsHealing(!isHealing)}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
            isHealing
              ? 'bg-green-500 hover:bg-green-600 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
          }`}
        >
          {isHealing ? <Pause size={20} /> : <Play size={20} />}
          {isHealing ? 'Healing Active' : 'Start Healing'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/30 rounded-xl p-6">
          <Wrench className="text-purple-400 mb-3" size={32} />
          <div className="text-3xl font-bold text-white mb-1">6</div>
          <div className="text-sm text-purple-400">Healing Iterations</div>
          <div className="text-xs text-purple-400/70 mt-1">Continuous improvement</div>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-xl p-6">
          <TrendingUp className="text-green-400 mb-3" size={32} />
          <div className="text-3xl font-bold text-white mb-1">+31%</div>
          <div className="text-sm text-green-400">Fairness Improvement</div>
          <div className="text-xs text-green-400/70 mt-1">From 65% to 85%</div>
        </div>

        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30 rounded-xl p-6">
          <TrendingUp className="text-blue-400 mb-3" size={32} />
          <div className="text-3xl font-bold text-white mb-1">87%</div>
          <div className="text-sm text-blue-400">Retained Accuracy</div>
          <div className="text-xs text-blue-400/70 mt-1">-5% acceptable trade-off</div>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Healing Progress</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="iteration" tick={{ fill: '#9CA3AF' }} label={{ value: 'Iteration', position: 'insideBottom', offset: -5, fill: '#9CA3AF' }} />
            <YAxis tick={{ fill: '#9CA3AF' }} label={{ value: 'Score (%)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
              labelStyle={{ color: '#F3F4F6' }}
            />
            <Legend wrapperStyle={{ color: '#9CA3AF' }} />
            <Line type="monotone" dataKey="fairness" stroke="#10B981" strokeWidth={3} dot={{ r: 5 }} name="Fairness Score" />
            <Line type="monotone" dataKey="accuracy" stroke="#3B82F6" strokeWidth={3} dot={{ r: 5 }} name="Accuracy" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Healing Techniques</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {techniques.map((technique) => (
            <div
              key={technique.id}
              className={`border rounded-xl p-5 transition-all cursor-pointer ${
                activeTechniques.includes(technique.id)
                  ? 'bg-blue-500/10 border-blue-500/30 hover:border-blue-500/50'
                  : 'bg-gray-900/50 border-gray-700 hover:border-gray-600'
              }`}
              onClick={() => toggleTechnique(technique.id)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="text-white font-semibold mb-1">{technique.name}</h4>
                  <p className="text-gray-400 text-sm">{technique.description}</p>
                </div>
                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  activeTechniques.includes(technique.id)
                    ? 'border-blue-500 bg-blue-500'
                    : 'border-gray-600'
                }`}>
                  {activeTechniques.includes(technique.id) && (
                    <div className="w-2 h-2 bg-white rounded-full" />
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-700">
                <span className={`text-xs font-semibold px-2 py-1 rounded ${
                  activeTechniques.includes(technique.id)
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-gray-700 text-gray-400'
                }`}>
                  {activeTechniques.includes(technique.id) ? 'ACTIVE' : 'IDLE'}
                </span>
                <span className="text-sm text-green-400 font-semibold">{technique.impact}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
