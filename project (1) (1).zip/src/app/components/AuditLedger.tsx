import { FileText, Download, Search, Filter } from 'lucide-react';
import { useState } from 'react';

const auditLogs = [
  {
    id: 'AUD-2024-9821',
    timestamp: '2026-04-28 14:32:15',
    model: 'Credit-ML-v3',
    input: { creditScore: 720, income: 85000, age: 34, gender: 'Female' },
    prediction: 'Denied',
    biasScore: 0.42,
    correctionApplied: 'Re-weighted to Approved',
    auditTrail: 'Auto-healing enabled, threshold adjusted',
    reviewer: 'AI-System',
  },
  {
    id: 'AUD-2024-9820',
    timestamp: '2026-04-28 14:31:52',
    model: 'Hiring-DL-v2',
    input: { experience: 8, education: 'Masters', age: 45, gender: 'Male' },
    prediction: 'Rejected',
    biasScore: 0.78,
    correctionApplied: 'Blocked - High Risk',
    auditTrail: 'Decision firewall intervention, flagged for manual review',
    reviewer: 'AI-System',
  },
  {
    id: 'AUD-2024-9819',
    timestamp: '2026-04-28 14:30:28',
    model: 'Loan-RF-v4',
    input: { income: 120000, debt: 45000, age: 29, location: 'Urban' },
    prediction: 'Approved',
    biasScore: 0.15,
    correctionApplied: 'None',
    auditTrail: 'Passed fairness check, no intervention required',
    reviewer: 'AI-System',
  },
  {
    id: 'AUD-2024-9818',
    timestamp: '2026-04-28 14:29:41',
    model: 'Credit-ML-v3',
    input: { creditScore: 680, income: 62000, age: 52, gender: 'Female' },
    prediction: 'Denied',
    biasScore: 0.61,
    correctionApplied: 'Re-weighted to Approved',
    auditTrail: 'SHAP analysis revealed age bias, applied correction',
    reviewer: 'AI-System',
  },
  {
    id: 'AUD-2024-9817',
    timestamp: '2026-04-28 14:28:19',
    model: 'Hiring-DL-v2',
    input: { experience: 5, education: 'Bachelors', age: 28, gender: 'Non-binary' },
    prediction: 'Accepted',
    biasScore: 0.22,
    correctionApplied: 'None',
    auditTrail: 'Low bias score, prediction approved',
    reviewer: 'AI-System',
  },
];

export function AuditLedger() {
  const [selectedLog, setSelectedLog] = useState(auditLogs[0]);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Audit & Trust Ledger</h2>
          <p className="text-gray-400 mt-1">Immutable record of all decisions and corrections</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold transition-all">
            <Download size={18} />
            Export Logs
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30 rounded-xl p-6">
          <FileText className="text-blue-400 mb-2" size={24} />
          <div className="text-3xl font-bold text-white mb-1">8,472</div>
          <div className="text-sm text-blue-400">Total Decisions</div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30 rounded-xl p-6">
          <FileText className="text-yellow-400 mb-2" size={24} />
          <div className="text-3xl font-bold text-white mb-1">1,234</div>
          <div className="text-sm text-yellow-400">Corrected</div>
          <div className="text-xs text-yellow-400/70 mt-1">14.6% correction rate</div>
        </div>

        <div className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/30 rounded-xl p-6">
          <FileText className="text-red-400 mb-2" size={24} />
          <div className="text-3xl font-bold text-white mb-1">287</div>
          <div className="text-sm text-red-400">Blocked</div>
          <div className="text-xs text-red-400/70 mt-1">3.4% block rate</div>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-xl p-6">
          <FileText className="text-green-400 mb-2" size={24} />
          <div className="text-3xl font-bold text-white mb-1">100%</div>
          <div className="text-sm text-green-400">Audit Coverage</div>
          <div className="text-xs text-green-400/70 mt-1">Full transparency</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <input
                type="text"
                placeholder="Search by ID, model, or attribute..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
              />
            </div>
            <button className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-all">
              <Filter size={18} />
              Filter
            </button>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                onClick={() => setSelectedLog(log)}
                className={`border rounded-lg p-4 cursor-pointer transition-all ${
                  selectedLog.id === log.id
                    ? 'bg-blue-500/10 border-blue-500/30'
                    : 'bg-gray-900/50 border-gray-700 hover:border-gray-600'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-white font-mono text-sm font-semibold">{log.id}</div>
                    <div className="text-gray-500 text-xs">{log.timestamp}</div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-semibold ${
                    log.correctionApplied.includes('Blocked')
                      ? 'bg-red-500/20 text-red-400'
                      : log.correctionApplied === 'None'
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {log.correctionApplied.split(' ')[0]}
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-gray-400">{log.model}</span>
                  <span className="text-gray-600">•</span>
                  <span className={`font-semibold ${
                    log.biasScore > 0.6 ? 'text-red-400' :
                    log.biasScore > 0.3 ? 'text-yellow-400' :
                    'text-green-400'
                  }`}>
                    Bias: {(log.biasScore * 100).toFixed(0)}%
                  </span>
                  <span className="text-gray-600">•</span>
                  <span className={`${
                    log.prediction.includes('Denied') || log.prediction.includes('Rejected')
                      ? 'text-red-400'
                      : 'text-green-400'
                  }`}>
                    {log.prediction}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Log Details</h3>
          <div className="space-y-4">
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Audit ID</div>
              <div className="text-white font-mono text-sm">{selectedLog.id}</div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Timestamp</div>
              <div className="text-white text-sm">{selectedLog.timestamp}</div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-2">Input Features</div>
              <div className="space-y-1">
                {Object.entries(selectedLog.input).map(([key, value]) => (
                  <div key={key} className="flex justify-between text-xs">
                    <span className="text-gray-400 capitalize">{key}:</span>
                    <span className="text-white font-medium">{value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Original Prediction</div>
              <div className="text-white font-semibold">{selectedLog.prediction}</div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Bias Score</div>
              <div className={`text-2xl font-bold ${
                selectedLog.biasScore > 0.6 ? 'text-red-400' :
                selectedLog.biasScore > 0.3 ? 'text-yellow-400' :
                'text-green-400'
              }`}>
                {(selectedLog.biasScore * 100).toFixed(0)}/100
              </div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Correction Applied</div>
              <div className="text-white text-sm">{selectedLog.correctionApplied}</div>
            </div>

            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">Audit Trail</div>
              <div className="text-gray-300 text-xs leading-relaxed">{selectedLog.auditTrail}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
